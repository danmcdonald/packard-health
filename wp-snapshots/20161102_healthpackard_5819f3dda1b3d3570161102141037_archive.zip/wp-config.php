<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'ph');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'uS[/(^abc][eLm`@`?rWv*8fU<2 zF3c8:SZ9S}=zRcll}x)^dHs1.mrc]$sIIR@');
define('SECURE_AUTH_KEY',  '8bpDa7+^yg_pzB(9N1YkB$M)MEA%)XL)aHF1IR;*yjB{NWPpJX=J*n-u)V];,j@%');
define('LOGGED_IN_KEY',    '5l(pVkd3xtW8HgqT~&my6,F,^zo:#C$5L _BUmdJT3(>GcGoqu9X>O8i;/PE:J+t');
define('NONCE_KEY',        '^ZBj*AaFs04ZY<y(f+vfUv>CMe7~Va6l8L`)d%;t>i(@yP_K$WLkzdMEBIK~2mvr');
define('AUTH_SALT',        '5eu>-%stK#ZS9yi!Hku@Vg&MJa41q7j1+EDVDANWYdA]bTR8O.E!sCJssuyY+GKo');
define('SECURE_AUTH_SALT', '^akBqa$P^kx,!cfW<vn1ptbYr6@t@u&H{W@H,`P[~lde/59SBz&rR=4o+i1cN)k5');
define('LOGGED_IN_SALT',   '2~P9I9m+ETdqT]^bg#7n1.1nw?`EzbLiNQ9Qm#j6%;s&f0f&K2:&Sye?1^|2cE9(');
define('NONCE_SALT',       'qe5^2%!? H5WRO/!s7zoe`T=;!e?* y]f,#(B|s;pu]}y)zx5Myw);{lW%DfdN.@');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpph_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
